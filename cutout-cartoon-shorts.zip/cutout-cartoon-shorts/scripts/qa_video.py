"""Checks on a rendered Short: stream info, loudness, audio gaps, pop scan (caption band masked) and loop check.
usage: python3 qa_video.py video.mp4 [--caption-band 0.72 0.84]
Read the output like this:
  * pop scan: smooth camera moves give a high but steady frame difference (that is fine). An isolated spike, far above its
    neighbours, is a pop - it must be an intended swap or cut. The caption band is masked because caption changes always spike.
  * loop check: first vs last frame should differ by < 0.2 (mean abs, 0-255) and have 0 pixels differing by more than 25.
  * audio gaps: silences should sit at the same times as the sentence gaps in timing.json."""
import argparse, json, re, subprocess, sys
import numpy as np

ap = argparse.ArgumentParser(); ap.add_argument("video"); ap.add_argument("--caption-band", nargs=2, type=float, default=[0.72, 0.84])
a = ap.parse_args()
v = a.video
pr = json.loads(subprocess.run(["ffprobe", "-v", "error", "-show_streams", "-show_format", "-of", "json", v], capture_output=True, text=True).stdout)
for s in pr["streams"]:
    if s["codec_type"] == "video":
        print("video:", s["codec_name"], f'{s["width"]}x{s["height"]}', s["r_frame_rate"], "fps,", s.get("nb_frames"), "frames,", s["duration"], "s")
    if s["codec_type"] == "audio":
        print("audio:", s["codec_name"], s["sample_rate"], "Hz,", s["channels"], "ch,", s["duration"], "s")
lg = subprocess.run(["ffmpeg", "-hide_banner", "-i", v, "-vn", "-af", "ebur128=peak=true", "-f", "null", "-"], capture_output=True, text=True).stderr
tail = lg[lg.rfind("Summary:"):]
print("loudness:", re.findall(r"I:\s+(-?[\d.]+) LUFS", tail)[-1:], "LUFS | LRA", re.findall(r"LRA:\s+([\d.]+) LU", tail)[-1:], "| true peak", re.findall(r"Peak:\s+(-?[\d.]+) dBFS", tail)[-1:], "dBFS")
sl = subprocess.run(["ffmpeg", "-hide_banner", "-i", v, "-vn", "-af", "silencedetect=noise=-42dB:d=0.12", "-f", "null", "-"], capture_output=True, text=True).stderr
print("audio gaps (start, length s):", [(round(float(s), 2), round(float(d), 2)) for s, d in zip(re.findall(r"silence_start: ([\d.]+)", sl), re.findall(r"silence_duration: ([\d.]+)", sl))])

W, H = 270, 480
p = subprocess.Popen(["ffmpeg", "-v", "error", "-i", v, "-vf", f"scale={W}:{H},format=gray", "-f", "rawvideo", "-pix_fmt", "gray", "-"], stdout=subprocess.PIPE)
fps = float(re.sub(r"/.*", "", [s for s in pr["streams"] if s["codec_type"] == "video"][0]["r_frame_rate"]))
r0, r1 = int(a.caption_band[0] * H), int(a.caption_band[1] * H)
prev = first = None; diffs = []
while True:
    buf = p.stdout.read(W * H)
    if len(buf) < W * H: break
    fr = np.frombuffer(buf, np.uint8).astype(np.float32).reshape(H, W)
    if first is None: first = fr
    if prev is not None:
        d = np.abs(fr - prev); d[r0:r1] = 0; diffs.append(float(d.mean()))
    prev = fr
diffs = np.array(diffs)
med = np.array([np.median(diffs[max(0, i - 15):i + 16]) for i in range(len(diffs))])
spikes = [(round((i + 1) / fps, 2), round(float(diffs[i]), 2), round(float(med[i]), 2)) for i in range(len(diffs)) if diffs[i] > max(3 * med[i], 1.0)]
print("pop scan: frames", len(diffs) + 1, "| max diff", round(float(diffs.max()), 2), "| isolated spikes (t, diff, local median):", spikes[:20])
dd = np.abs(first - prev)
print("loop check: mean abs diff", round(float(dd.mean()), 3), "| pixels differing > 25:", int((dd > 25).sum()))
