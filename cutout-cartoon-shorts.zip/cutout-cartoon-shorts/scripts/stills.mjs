import {bundle} from '@remotion/bundler';
import {renderStill, selectComposition} from '@remotion/renderer';
import path from 'node:path';
import fs from 'node:fs';
const root = path.resolve(import.meta.dirname, '..');
const times = process.argv.slice(2).map(Number);
const scale = Number(process.env.SCALE || 0.5);
const browserExecutable = '/opt/pw-browsers/chromium_headless_shell-1243/chrome-headless-shell-linux64/chrome-headless-shell';
const serveUrl = await bundle({entryPoint: path.join(root, 'src/index.ts'), outDir: path.join(root, '.bundle')});
const comp = await selectComposition({serveUrl, id: process.env.COMP || 'Eiffel', browserExecutable});
fs.mkdirSync(path.join(root, 'qa'), {recursive: true});
for (const t of times) {
  const frame = Math.min(comp.durationInFrames - 1, Math.round(t * comp.fps));
  const output = path.join(root, 'qa', `still_${t.toFixed(2)}.png`);
  await renderStill({composition: comp, serveUrl, output, frame, scale, browserExecutable, imageFormat: 'png'});
  console.log('ok', output);
}
