"""Synthesise the sound effects (numpy only) and mix them at the cue times from src/timing.json."""
import json, math, wave, pathlib
import numpy as np

ROOT = pathlib.Path(__file__).resolve().parent.parent
tm = json.loads((ROOT / "src" / "timing.json").read_text())
K, KE, DUR = tm["key"], tm["keyEnd"], tm["duration"]
SR = 44100
rng = np.random.default_rng(7)
N = int((DUR + 0.5) * SR)
mix = np.zeros(N)

def add(t, x, gain=1.0):
    i = int(t * SR)
    if i < 0: i = 0
    j = min(N, i + len(x))
    if j > i: mix[i:j] += x[: j - i] * gain

def env_ad(n, a=0.01, d=0.2):
    t = np.arange(n) / SR
    return np.minimum(1, t / max(a, 1e-4)) * np.exp(-t / d)

def tone(freq, dur, phase0=0.0):
    n = int(dur * SR)
    f = np.full(n, freq, float) if np.isscalar(freq) else np.asarray(freq)
    return np.sin(phase0 + 2 * np.pi * np.cumsum(f) / SR)

def sweep(f0, f1, dur, expo=True):
    n = int(dur * SR); u = np.linspace(0, 1, n)
    f = f0 * (f1 / f0) ** u if expo else f0 + (f1 - f0) * u
    return tone(f, dur)

def band_noise(dur, lo, hi):
    n = int(dur * SR); x = rng.standard_normal(n)
    X = np.fft.rfft(x); fr = np.fft.rfftfreq(n, 1 / SR)
    c = math.sqrt(lo * hi); w = math.log(hi / lo) / 2.2
    X *= np.exp(-((np.log(fr + 1) - math.log(c)) ** 2) / (2 * w * w))
    y = np.fft.irfft(X, n); return y / (np.abs(y).max() + 1e-9)

def swell(n, peak=0.5, power=2.0):
    u = np.linspace(0, 1, n)
    e = np.where(u < peak, (u / peak) ** power, ((1 - u) / (1 - peak)) ** power)
    return e

def bell(f, dur=1.3):
    n = int(dur * SR); t = np.arange(n) / SR
    x = np.sin(2 * np.pi * f * t) * np.exp(-t / 0.55) + 0.45 * np.sin(2 * np.pi * f * 2.01 * t) * np.exp(-t / 0.3) + 0.2 * np.sin(2 * np.pi * f * 3.02 * t) * np.exp(-t / 0.18)
    return x * np.minimum(1, t / 0.004)

def pop(t, g=0.5):
    x = sweep(420, 1500, 0.16) * env_ad(int(0.16 * SR), 0.003, 0.05); add(t, x, g)
    for i, f in enumerate([1760, 2217, 2637]): add(t + 0.06 + 0.055 * i, bell(f, 0.7) * 0.25, g)

def whoosh(t, dur, lo=300, hi=2600, g=0.35, peak=0.45):
    n = int(dur * SR); add(t, band_noise(dur, lo, hi) * swell(n, peak), g)

def creak(t, dur, g=0.3):
    n = int(dur * SR); tt = np.arange(n) / SR
    f = 70 + 22 * np.sin(2 * np.pi * 2.4 * tt) + 14 * np.sin(2 * np.pi * 5.3 * tt + 1) + 30 * tt / dur
    saw = 2 * ((np.cumsum(f) / SR) % 1) - 1
    X = np.fft.rfft(saw); fr = np.fft.rfftfreq(n, 1 / SR)
    X *= np.exp(-((np.log(fr + 1) - math.log(520)) ** 2) / (2 * 0.55 ** 2))
    y = np.fft.irfft(X, n); y /= np.abs(y).max() + 1e-9
    am = 0.55 + 0.45 * np.sin(2 * np.pi * 6.5 * tt + 0.5) ** 2
    add(t, y * am * swell(n, 0.35, 1.5), g)

def tick(t, g=0.18, f=1900):
    n = int(0.035 * SR); add(t, tone(f, 0.035) * env_ad(n, 0.001, 0.008), g)

def boing(t, g=0.3):
    n = int(0.6 * SR); tt = np.arange(n) / SR
    f = 190 + 140 * np.exp(-tt * 7) * np.sin(2 * np.pi * 9 * tt)
    add(t, tone(f, 0.6) * np.exp(-tt / 0.22), g)

# --- bed: very quiet breeze
bed = band_noise(DUR + 0.5, 140, 900) * (0.55 + 0.45 * np.sin(2 * np.pi * 0.11 * np.arange(N) / SR + 1) ** 2)
mix += bed[:N] * 0.035

# --- cues (all times from the word timeline)
pop(K["sunny"] - 0.08, 0.5)                                   # sun pops in
whoosh(K["day"] + 0.35, 1.2, 250, 1800, 0.30)                  # camera glides to the close-up
x = sweep(260, 820, 0.8, False) * (0.6 + 0.4 * np.sin(2 * np.pi * 14 * np.arange(int(0.8 * SR)) / SR)) * swell(int(0.8 * SR), 0.6, 1.5)
add(K["facing"] + 0.05, x, 0.16)                               # beams
n = int(1.6 * SR); add(K["heats"] - 0.05, band_noise(1.6, 2500, 9000) * swell(n, 0.35, 1.6), 0.22)   # heat sizzle
for _ in range(26): add(K["heats"] + rng.uniform(0, 1.6), tone(rng.uniform(2500, 5000), 0.012) * env_ad(int(0.012 * SR), 0.0005, 0.004), 0.1)
t0 = K["expands"] - 0.1                                        # thump + stretch
tt = np.arange(int(0.5 * SR)) / SR
add(t0, np.sin(2 * np.pi * 85 * tt * np.exp(-tt * 2)) * np.exp(-tt / 0.16), 0.5)
add(t0 + 0.05, sweep(170, 340, 0.45, False) * env_ad(int(0.45 * SR), 0.02, 0.2), 0.22)
add(K["cooler"] - 0.05, bell(880, 1.5), 0.30); add(K["cooler"] + 0.12, bell(1320, 1.2), 0.20)  # cool chime
whoosh(K["cooler"], 1.1, 400, 1600, 0.12, 0.5)                 # little breeze
whoosh(K["uneven"] - 0.1, 1.5, 250, 2000, 0.30)                # pull-back
creak(K["bends"] - 0.05, 1.9, 0.32)                            # the bend
boing(K["leans"] + 1.0, 0.18)                                  # settles
whoosh(K["across"] - 0.25, 1.9, 300, 2400, 0.30, 0.5)          # dolly up to the top
whoosh(tm["sunExit"] - 0.25, 0.9, 500, 3500, 0.16, 0.4)        # sun glides out
t_a, t_b = K["traces"] + 0.1, KE["wide"] - 0.05                # ring ticks
for i in range(14): tick(t_a + (t_b - t_a) * i / 13, 0.13 + 0.015 * i, 1500 + 40 * i)
add(K["fifteen"] + 0.05, bell(1318, 1.2), 0.30); add(K["fifteen"] + 0.2, bell(1976, 1.0), 0.22)      # ruler pops in
whoosh(KE["wide"] + 0.1, 1.4, 250, 2200, 0.28)                 # pull back to the start
boing(DUR - 0.9, 0.22)

peak = np.abs(mix).max()
mix = mix / peak * 0.7
pcm = (np.clip(mix, -1, 1) * 32767).astype("<i2")
stereo = np.repeat(pcm[:, None], 2, axis=1)
out = ROOT / "public" / "eiffel" / "sfx.wav"
with wave.open(str(out), "wb") as w:
    w.setnchannels(2); w.setsampwidth(2); w.setframerate(SR); w.writeframes(stereo.tobytes())
print("wrote", out, round(len(pcm) / SR, 2), "s")
