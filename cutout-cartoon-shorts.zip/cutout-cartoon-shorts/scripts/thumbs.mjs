import {bundle} from '@remotion/bundler';
import {renderStill, selectComposition} from '@remotion/renderer';
import path from 'node:path'; import fs from 'node:fs';
const root = path.resolve(import.meta.dirname, '..');
const browserExecutable = '/opt/pw-browsers/chromium_headless_shell-1243/chrome-headless-shell-linux64/chrome-headless-shell';
const scale = Number(process.env.SCALE || 1);
const variants = process.argv.slice(2).length ? process.argv.slice(2) : ['A', 'B', 'C'];
const serveUrl = await bundle({entryPoint: path.join(root, 'src/index.ts'), outDir: path.join(root, '.bundle')});
fs.mkdirSync(path.join(root, 'thumbnails'), {recursive: true});
for (const v of variants) {
  const comp = await selectComposition({serveUrl, id: 'Thumb', browserExecutable, inputProps: {variant: v}});
  const output = path.join(root, 'thumbnails', `thumb_${v}_${scale}x.png`);
  await renderStill({composition: comp, serveUrl, output, frame: 0, scale, browserExecutable, imageFormat: 'png', inputProps: {variant: v}});
  console.log('ok', output);
}
