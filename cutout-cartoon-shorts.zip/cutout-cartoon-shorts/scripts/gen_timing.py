"""Word timing -> timing.json: the single source for captions, animation beats, camera moves and sound cues.

usage:  python3 gen_timing.py story.json [--take word_times_file.json] [--out src/timing.json]

story.json
  lead            seconds of picture before the first word (default 0.4)
  tail            seconds after the last word (pull-back / loop-back; default 1.5, never below 0.5)
  syllableRate    estimate mode only: syllables per second (default 4.2)
  chunks          caption chunks: [[["The",1],["Eiffel",2],["Tower",2]], ...]   (word, syllables)
  keys            named beats: {"sunny": ["sunny", 0], ...}  (word, occurrence) -> key[name] = word start, keyEnd[name] = word end
  motion          optional: {"startKey","endKey","endPad","exitFraction"}  -> psiT0, psiT1, sunExit (a 0..2pi motion that
                  starts at a key and ends after another; exitFraction of pi = when something leaves the frame)

Voice mode (--take): word times are MEASURED from the voice take (see align_take.py + refine_align.py) and shifted so the
first word lands at `lead`; voiceOffset = where the voice file must start in the video.
Estimate mode (no --take): syllable model; use it to plan beats, caption windows and the timing sheet before a voice exists."""
import argparse, json, math, pathlib, re

ap = argparse.ArgumentParser()
ap.add_argument("story"); ap.add_argument("--take"); ap.add_argument("--out", default="src/timing.json")
a = ap.parse_args()
story = json.loads(pathlib.Path(a.story).read_text())
LEAD, TAIL, SYL = story.get("lead", 0.4), max(0.5, story.get("tail", 1.5)), story.get("syllableRate", 4.2)
chunks = story["chunks"]
flat = [(ci, w, s) for ci, ch in enumerate(chunks) for w, s in ch]
letters = lambda x: re.sub(r"[^a-z]", "", x.lower())

words, offset = [], None
if a.take:
    voice = json.loads(pathlib.Path(a.take).read_text())
    assert len(voice["words"]) == len(flat), (len(voice["words"]), len(flat))
    offset = LEAD - voice["words"][0]["t0"]            # where the voice file starts in the video
    for (ci, w, s), v in zip(flat, voice["words"]):
        assert letters(w) == letters(v["w"]), (w, v["w"])
        words.append(dict(w=w, t0=round(v["t0"] + offset, 3), t1=round(v["t1"] + offset, 3), chunk=ci))
    mode = "voice"
else:
    cur = LEAD
    for ci, w, s in flat:
        t0, t1 = cur, cur + s / SYL
        words.append(dict(w=w, t0=round(t0, 3), t1=round(t1, 3), chunk=ci))
        cur = t1 + 0.02 + (0.20 if w.endswith(",") else 0) + (0.50 if w.endswith(".") else 0)
    mode = "estimate"

chunk_meta = []
for ci, ch in enumerate(chunks):
    idx = [i for i, w in enumerate(words) if w["chunk"] == ci]
    chunk_meta.append(dict(text=" ".join(w for w, _ in ch), first=idx[0], last=idx[-1], t0=words[idx[0]]["t0"], t1=words[idx[-1]]["t1"]))

def find(name, occ=0):
    n = 0
    for i, w in enumerate(words):
        if letters(w["w"]) == name:
            if n == occ:
                return i
            n += 1
    raise KeyError(name)

key = {k: words[find(*v)]["t0"] for k, v in story.get("keys", {}).items()}
key_end = {k: words[find(*v)]["t1"] for k, v in story.get("keys", {}).items()}
duration = round(words[-1]["t1"] + TAIL, 3)

out = dict(words=words, chunks=chunk_meta, key=key, keyEnd=key_end, duration=duration, wordCount=len(words), mode=mode,
           voiceOffset=round(offset, 3) if offset is not None else None)
m = story.get("motion")
if m:                                                   # motion 0 -> 2pi over [startKey, endKey end + pad], ease-in-out sine
    t0, t1 = key[m["startKey"]], key_end[m["endKey"]] + m.get("endPad", 0.1)
    inv = lambda y: math.acos(1 - 2 * y) / math.pi
    out.update(psiT0=t0, psiT1=t1, sunExit=round(t0 + inv(m.get("exitFraction", 0.95) / 2) * (t1 - t0), 3))
p = pathlib.Path(a.out); p.parent.mkdir(parents=True, exist_ok=True); p.write_text(json.dumps(out, indent=1))
print(mode, "| words", len(words), "| duration", duration, "| voice file starts at", out["voiceOffset"])
