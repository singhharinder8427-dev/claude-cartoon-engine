"""Forced-align a voice take to its script (word start/end times). Needs pocketsphinx - run it inside a venv:
    python3 -m venv /tmp/alignenv && /tmp/alignenv/bin/pip install pocketsphinx numpy
    /tmp/alignenv/bin/python align_take.py take.mp3 script.txt aligned.json [align_text.txt]

script.txt      the narration exactly as captioned (one line is fine)
align_text.txt  optional: the same number of words spelled as they are pronounced (names, numbers, words missing from the
                dictionary); captions keep the script.txt spelling.
Output: aligned.json = [{"w","t0","t1"}] in file time (seconds). Then run refine_align.py."""
import json, pathlib, re, subprocess, sys
from pocketsphinx import Decoder

take, script, out = sys.argv[1:4]
words = pathlib.Path(script).read_text().split()
atext = pathlib.Path(sys.argv[4]).read_text().split() if len(sys.argv) > 4 else [re.sub(r"[^a-z']", "", w.lower()) for w in words]
assert len(atext) == len(words), (len(atext), len(words))
raw = subprocess.run(["ffmpeg", "-v", "error", "-i", take, "-ar", "16000", "-ac", "1", "-f", "s16le", "-"], capture_output=True, check=True).stdout
d = Decoder(samprate=16000)
d.set_align_text(" ".join(atext))
d.start_utt(); d.process_raw(raw, False, True); d.end_utt()
segs = [(s.word, s.start_frame / 100.0, (s.end_frame + 1) / 100.0) for s in d.seg()]
res = [s for s in segs if not s[0].startswith(("<", "[")) and s[0] != "(NULL)"]
if len(res) != len(words):
    sys.exit(f"aligned {len(res)} words, expected {len(words)}: check for words missing from the dictionary (use align_text.txt)")
pathlib.Path(out).write_text(json.dumps([dict(w=w, t0=a, t1=b) for w, a, b in res], indent=1))
print(len(res), "words aligned; speech ends about", res[-1][2])
