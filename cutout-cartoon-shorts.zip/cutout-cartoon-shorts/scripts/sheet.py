import sys
from PIL import Image, ImageDraw
files = sys.argv[2:]
out = sys.argv[1]
ims = [Image.open(f).convert('RGB') for f in files]
w, h = ims[0].size
cols = 3 if len(ims) > 2 else len(ims)
rows = (len(ims) + cols - 1) // cols
sc = 0.62
tw, th = int(w * sc), int(h * sc)
sheet = Image.new('RGB', (cols * tw, rows * th), 'white')
for i, im in enumerate(ims):
    sheet.paste(im.resize((tw, th), Image.LANCZOS), ((i % cols) * tw, (i // cols) * th))
    ImageDraw.Draw(sheet).text(((i % cols) * tw + 6, (i // cols) * th + 6), files[i].split('still_')[-1][:-4] + 's', fill='black')
sheet.save(out)
print(sheet.size)
