"""Snap forced-alignment word edges to the real silences of the take.
usage: python3 refine_align.py take.mp3 aligned.json script.txt word_times_file.json
Rules (learned the hard way):
  * silences are found with ffmpeg silencedetect at -42 dB, minimum 0.12 s. Do NOT use 0.10 s: plosive closures inside words
    (the "p" in "up") show up as 0.1 s silences and would be mistaken for word gaps.
  * a silence starting before 0.05 s is leading silence; one that runs to the end of the file is the end of speech.
  * a silence is snapped to a word boundary only if the aligner's boundary lies within 0.15 s of it.
  * the first word starts at the first sound above -40 dB.
Output: {"onset","fileDuration","words":[{"w","t0","t1"}]} in file time, the input of gen_timing.py --take."""
import array, json, math, pathlib, re, subprocess, sys

take, aligned_p, script_p, out = sys.argv[1:5]
aligned = json.loads(pathlib.Path(aligned_p).read_text())
SCRIPT = pathlib.Path(script_p).read_text().split()
assert len(SCRIPT) == len(aligned), (len(SCRIPT), len(aligned))
dur = float(subprocess.run(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", take], capture_output=True, text=True).stdout)
log = subprocess.run(["ffmpeg", "-hide_banner", "-i", take, "-af", "silencedetect=noise=-42dB:d=0.12", "-f", "null", "-"], capture_output=True, text=True).stderr
starts = [float(x) for x in re.findall(r"silence_start: ([\d.]+)", log)]
ends = [float(x) for x in re.findall(r"silence_end: ([\d.]+)", log)]
sil = list(zip(starts, ends + [dur] * (len(starts) - len(ends))))
W = [dict(w=SCRIPT[i], t0=a["t0"], t1=a["t1"]) for i, a in enumerate(aligned)]
snapped = []
for s, e in sil:
    if s < 0.05:
        continue
    if e >= dur - 0.03:
        W[-1]["t1"] = s; snapped.append(("end", round(s, 2))); continue
    best, bi = 9, None
    for i in range(len(W) - 1):
        b = (W[i]["t1"] + W[i + 1]["t0"]) / 2
        d = 0 if s - 0.15 <= b <= e + 0.15 else min(abs(b - s), abs(b - e))
        if d < best: best, bi = d, i
    if bi is not None and best == 0:
        W[bi]["t1"] = round(s, 3); W[bi + 1]["t0"] = round(e, 3); snapped.append((W[bi]["w"] + "|" + W[bi + 1]["w"], round(s, 2), round(e, 2)))
env = subprocess.run(["ffmpeg", "-v", "error", "-i", take, "-t", "0.6", "-ar", "8000", "-ac", "1", "-f", "s16le", "-"], capture_output=True).stdout
a = array.array("h"); a.frombytes(env)
onset, step, thr = 0.0, 80, 32768 * 10 ** (-40 / 20)
for i in range(0, len(a) - step, step):
    if math.sqrt(sum(x * x for x in a[i:i + step]) / step) > thr:
        onset = i / 8000; break
W[0]["t0"] = round(onset, 3)
for w in W: w["t0"] = round(w["t0"], 3); w["t1"] = round(w["t1"], 3)
for i in range(len(W) - 1):
    if W[i]["t1"] > W[i + 1]["t0"]: W[i]["t1"] = W[i + 1]["t0"]
pathlib.Path(out).write_text(json.dumps(dict(onset=onset, fileDuration=dur, words=W), indent=1))
print("snapped:", snapped); print("onset", onset, "speech end", W[-1]["t1"], "file", dur)
