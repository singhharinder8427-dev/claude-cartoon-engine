import React from 'react';
import {AbsoluteFill} from 'remotion';
import {Layer, Cam, proj, useK} from './Layer';
import {Sky, FarHills, MidHills, TowerGround, Cloud} from './Scenery';
import {Sun} from './Sun';
import {Tower, TowerProps, Face, geom, TX, TY, TH} from './Tower';
import {Character, Pose} from './Character';
import {INK, C} from './theme';

const FONT = 'Inter, "DejaVu Sans", sans-serif';

// ---------------------------------------------------------------- helpers
const Txt: React.FC<{y: number; size: number; color?: string; align?: 'left' | 'center' | 'right'; stroke?: number; rot?: number; pad?: number; children: React.ReactNode}> =
  ({y, size, color = '#fff', align = 'center', stroke = 30, rot = 0, pad = 44, children}) => (
    <div style={{position: 'absolute', left: 0, right: 0, top: y, textAlign: align, padding: `0 ${pad}px`, fontFamily: FONT, fontWeight: 900, fontSize: size, lineHeight: 1,
      letterSpacing: -3, color, WebkitTextStroke: `${stroke}px #111`, paintOrder: 'stroke fill', textShadow: '0 12px 0 rgba(0,0,0,0.30)', transform: `rotate(${rot}deg)`, whiteSpace: 'nowrap'} as React.CSSProperties}>
      {children}
    </div>
  );

const at = (Z: number, cam: Cam, sx: number, sy: number) => {
  const k = 1000 / (Z - cam.z);
  return {x: cam.x + (sx - 540) / k, y: cam.y + (sy - 960) / k};
};
const Clouds: React.FC<{cam: Cam; spots: [number, number, number][]}> = ({cam, spots}) => (
  <Layer cam={cam} z={5000}>
    {spots.map(([sx, sy, s], i) => { const p = at(5000, cam, sx, sy); return <Cloud key={i} x={p.x} y={p.y} s={s} />; })}
  </Layer>
);

const baseFace: Face = {lookX: 0, lookY: 0, lidL: 0, lidR: 0, lidTilt: 0, strain: 0, happy: 0, brow: 0, browL: 0, browR: 0, mouth: 'smile', sweat: 0, sweatSlide: 0, blink: 0};
const tp = (o: Partial<TowerProps>): TowerProps => ({t: 1.3, lean: {x: 0, y: 0}, tremble: 0, warmL: 0, warmR: 0, coolL: 0, coolR: 0, bulgeL: 0, bulgeR: 0,
  wavesL: 0, wavesR: 0, arrowsL: 0, arrowsR: 0, face: baseFace, ...o});

const Scale: React.FC = () => (
  <div style={{position: 'absolute', left: 0, right: 0, top: 1650, textAlign: 'center', fontFamily: FONT, fontWeight: 800, fontSize: 34, color: '#fff',
    WebkitTextStroke: '8px #111', paintOrder: 'stroke fill', opacity: 0.9, letterSpacing: 1} as React.CSSProperties}>
    exaggerated · not to scale
  </div>
);

const Snowflake: React.FC<{x: number; y: number; s: number}> = ({x, y, s}) => (
  <svg width={1080} height={1920} viewBox="0 0 1080 1920" style={{position: 'absolute', left: 0, top: 0}}>
    <g transform={`translate(${x} ${y}) scale(${s})`} strokeLinecap="round">
      {[0, 60, 120].map((a) => <line key={'o' + a} transform={`rotate(${a})`} x1={0} y1={-70} x2={0} y2={70} stroke={INK} strokeWidth={34} />)}
      {[0, 60, 120].map((a) => <line key={'f' + a} transform={`rotate(${a})`} x1={0} y1={-70} x2={0} y2={70} stroke="#EAF9FF" strokeWidth={16} />)}
      {[0, 60, 120, 180, 240, 300].map((a) => <g key={'b' + a} transform={`rotate(${a}) translate(0 -46)`}>
        <line x1={0} y1={0} x2={-20} y2={-18} stroke={INK} strokeWidth={30} /><line x1={0} y1={0} x2={20} y2={-18} stroke={INK} strokeWidth={30} />
        <line x1={0} y1={0} x2={-20} y2={-18} stroke="#EAF9FF" strokeWidth={13} /><line x1={0} y1={0} x2={20} y2={-18} stroke="#EAF9FF" strokeWidth={13} />
      </g>)}
    </g>
  </svg>
);

const Beams: React.FC<{sun: {x: number; y: number}; pts: [number, number][]}> = ({sun, pts}) => (
  <svg width={1080} height={1920} viewBox="0 0 1080 1920" style={{position: 'absolute', left: 0, top: 0}}>
    {pts.map(([ex, ey], i) => {
      const dx = ex - sun.x, dy = ey - sun.y, len = Math.hypot(dx, dy), nx = dx / len, ny = dy / len;
      const x0 = sun.x + nx * 170, y0 = sun.y + ny * 170, x1 = ex - nx * 46, y1 = ey - ny * 46;
      return <g key={i}><line x1={x0} y1={y0} x2={x1} y2={y1} stroke={INK} strokeWidth={26} strokeLinecap="round" />
        <line x1={x0} y1={y0} x2={x1} y2={y1} stroke="#FFD21F" strokeWidth={13} strokeLinecap="round" strokeDasharray="34 26" /></g>;
    })}
  </svg>
);

const shocked: Pose = {lean: 6, sx: 1, sy: 1, faceDx: 12, faceDy: -16, lookX: 0.8, lookY: -1, eyeOpen: 1.2, browY: -12, browTilt: -14, mouth: 'o',
  armL: [-82, -84], armR: [176, -372], sweat: 0, sweatSlide: 0, headTilt: 0};

// ---------------------------------------------------------------- A: the dramatic lean
const ThumbA: React.FC = () => {
  const camT: Cam = {x: 540, y: 160, z: -66};
  const camC: Cam = {x: 452, y: 848, z: 260};
  const lean = {x: 330, y: 0};
  const g = geom(lean, 0.9, 0);
  const sun = {x: 190, y: 770};
  const beams = [0.3, 0.45, 0.6].map((u) => { const e = g.edge(u, -1); return proj(2000, e[0], e[1], camT); });
  const face: Face = {...baseFace, strain: 1, brow: 22, mouth: 'grit'};
  return (
    <AbsoluteFill>
      <Sky />
      <Sun x={sun.x} y={sun.y} s={1.15} t={2} />
      <Clouds cam={camT} spots={[[900, 800, 3.2], [880, 1180, 3.0], [200, 1090, 2.4]]} />
      <Layer cam={camT} z={4000}><FarHills /></Layer>
      <Layer cam={camT} z={3000}><MidHills /></Layer>
      <Layer cam={camT} z={2000}>
        <TowerGround />
        <Tower {...tp({lean, warmL: 0.95, coolR: 0.85, bulgeL: 0.9, wavesL: 0.95, arrowsL: 1, face})} />
      </Layer>
      <div style={{position: 'absolute', left: 0, right: 0, top: 1580, bottom: 0, background: C.near}} />
      <Beams sun={sun} pts={beams} />
      <Layer cam={camC} z={1000}><g transform="translate(190 1330)"><Character pose={shocked} /></g></Layer>
      <Txt y={300} size={150} color="#fff">IT NEVER</Txt>
      <Txt y={455} size={108} color="#FFE14D">STANDS STILL</Txt>
      <Scale />
    </AbsoluteFill>
  );
};

// ---------------------------------------------------------------- B: hot side / cool side face
const ThumbB: React.FC = () => {
  const camT: Cam = {x: 540, y: 849, z: 1500};
  const lean = {x: 140, y: 0};
  const face: Face = {...baseFace, lookX: -0.25, lookY: -0.55, lidL: 0.58, lidR: 0.22, lidTilt: 14, brow: 10, mouth: 'smirk', sweat: 1, sweatSlide: 0.42};
  return (
    <AbsoluteFill>
      <Sky />
      <Sun x={150} y={720} s={1.1} t={2} />
      <Clouds cam={camT} spots={[[870, 1180, 3.4], [700, 520, 2.4]]} />
      <Layer cam={camT} z={4000}><FarHills /></Layer>
      <Layer cam={camT} z={3000}><MidHills /></Layer>
      <Layer cam={camT} z={2000}>
        <Tower {...tp({lean, warmL: 1, coolR: 1, bulgeL: 1, wavesL: 0, face})} />
      </Layer>
      <Snowflake x={905} y={700} s={1.25} />
      <Snowflake x={960} y={980} s={0.8} />
      <Txt y={300} size={165} color="#FF8A3D" align="left" pad={90} rot={-3}>HOT</Txt>
      <Txt y={300} size={165} color="#8FD8FF" align="right" pad={90} rot={3}>COOL</Txt>
      <Txt y={1320} size={112} color="#fff">WHY IT</Txt>
      <Txt y={1435} size={195} color="#FFE14D">LEANS</Txt>
      <Scale />
    </AbsoluteFill>
  );
};

// ---------------------------------------------------------------- C: the circle at the top
const R_LEAN = 200, RING_Y = 0.36;
const ThumbC: React.FC = () => {
  const camT: Cam = {x: 540, y: -470, z: 1500};
  const psi = 0.3 * Math.PI;
  const lean = {x: R_LEAN * Math.cos(psi), y: -RING_Y * R_LEAN * Math.sin(psi)};
  const cy = TY - TH;
  const by = cy + RING_Y * R_LEAN + 78;
  const [lbx, lby] = proj(2000, TX, by, camT);
  const Ring: React.FC = () => {
    const k = useK();
    let d = '';
    for (let a = psi + 0.55; a <= psi + 2 * Math.PI - 0.1; a += 0.05) d += `${d ? 'L' : 'M'} ${(TX + R_LEAN * Math.cos(a)).toFixed(1)} ${(cy - RING_Y * R_LEAN * Math.sin(a)).toFixed(1)} `;
    const tip = {x: TX + lean.x, y: cy + lean.y};
    return (
      <g>
        <path d={d} fill="none" stroke={INK} strokeWidth={30 / k} strokeLinecap="round" strokeDasharray={`${40 / k} ${30 / k}`} />
        <path d={d} fill="none" stroke="#FF4B33" strokeWidth={16 / k} strokeLinecap="round" strokeDasharray={`${40 / k} ${30 / k}`} />
        <circle cx={tip.x} cy={tip.y} r={26 / k} fill="#FFE14D" stroke={INK} strokeWidth={10 / k} />
        <path d={`M ${TX - R_LEAN} ${by} L ${TX + R_LEAN} ${by} M ${TX - R_LEAN} ${by - 26} L ${TX - R_LEAN} ${by + 26} M ${TX + R_LEAN} ${by - 26} L ${TX + R_LEAN} ${by + 26}`}
          fill="none" stroke={INK} strokeWidth={26 / k} strokeLinecap="round" />
        <path d={`M ${TX - R_LEAN} ${by} L ${TX + R_LEAN} ${by} M ${TX - R_LEAN} ${by - 26} L ${TX - R_LEAN} ${by + 26} M ${TX + R_LEAN} ${by - 26} L ${TX + R_LEAN} ${by + 26}`}
          fill="none" stroke="#fff" strokeWidth={12 / k} strokeLinecap="round" />
      </g>
    );
  };
  return (
    <AbsoluteFill>
      <Sky />
      <Sun x={95} y={705} s={0.95} t={2} />
      <Clouds cam={camT} spots={[[890, 640, 3.0], [200, 1500, 3.0], [930, 1480, 3.2]]} />
      <Layer cam={camT} z={4000}><FarHills /></Layer>
      <Layer cam={camT} z={3000}><MidHills /></Layer>
      <Layer cam={camT} z={2000}>
        <Tower {...tp({lean, warmL: 0.3, wavesL: 0, face: baseFace})} />
        <Ring />
      </Layer>
      <div style={{position: 'absolute', left: lbx, top: lby + 40, transform: 'translate(-50%, 0)', textAlign: 'center', fontFamily: FONT, fontWeight: 900, color: '#fff',
        WebkitTextStroke: '22px #111', paintOrder: 'stroke fill', whiteSpace: 'nowrap', textShadow: '0 10px 0 rgba(0,0,0,0.30)'} as React.CSSProperties}>
        <div style={{fontSize: 150, letterSpacing: -3}}>≈ 15 cm</div>
      </div>
      <Txt y={300} size={150} color="#fff">IT DRAWS</Txt>
      <Txt y={455} size={122} color="#FFE14D">A CIRCLE</Txt>
      <Scale />
    </AbsoluteFill>
  );
};

export const Thumb: React.FC<{variant: 'A' | 'B' | 'C'}> = ({variant}) => (variant === 'B' ? <ThumbB /> : variant === 'C' ? <ThumbC /> : <ThumbA />);
