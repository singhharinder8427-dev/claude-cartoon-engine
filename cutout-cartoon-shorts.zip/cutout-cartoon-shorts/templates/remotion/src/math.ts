export const clamp = (x: number, a = 0, b = 1) => Math.min(b, Math.max(a, x));
export const lerp = (a: number, b: number, u: number) => a + (b - a) * u;
export const eio = (u: number) => (u < 0.5 ? 4 * u * u * u : 1 - Math.pow(-2 * u + 2, 3) / 2);
export const eioSine = (u: number) => -(Math.cos(Math.PI * u) - 1) / 2;
export const eo = (u: number) => 1 - Math.pow(1 - u, 3);
export const lin = (u: number) => u;
export const eob = (u: number) => { const c1 = 1.70158, c3 = c1 + 1; return 1 + c3 * Math.pow(u - 1, 3) + c1 * Math.pow(u - 1, 2); };
export const ramp = (t: number, a: number, b: number, e: (u: number) => number = eio) => e(clamp((t - a) / (b - a)));
/** smooth keyframes: [time, value] pairs, smoothstep between them */
export const kfs = (t: number, pts: [number, number][]) => {
  if (t <= pts[0][0]) return pts[0][1];
  for (let i = 0; i < pts.length - 1; i++) {
    const [t0, v0] = pts[i], [t1, v1] = pts[i + 1];
    if (t <= t1) { const u = t1 === t0 ? 1 : (t - t0) / (t1 - t0); return v0 + (v1 - v0) * u * u * (3 - 2 * u); }
  }
  return pts[pts.length - 1][1];
};
/** step keyframes: latest value whose time <= t */
export function pick<T>(t: number, pts: [number, T][]): T { let v = pts[0][1]; for (const [tt, vv] of pts) if (t >= tt) v = vv; return v; }
/** blink: 0 open .. 1 closed */
export const blinkAt = (t: number, times: number[]) => { let c = 0; for (const b of times) { const u = (t - b) / 0.16; if (u > 0 && u < 1) c = Math.max(c, Math.sin(Math.PI * u)); } return c; };
