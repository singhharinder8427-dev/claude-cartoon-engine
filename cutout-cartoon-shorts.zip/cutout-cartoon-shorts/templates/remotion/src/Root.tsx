import React from 'react';
import {Composition} from 'remotion';
import {Eiffel} from './Eiffel';
import {Thumb} from './Thumb';
import {DURATION, FPS} from './timing';

export const Root: React.FC = () => (
  <>
  <Composition id="Thumb" component={Thumb} width={1080} height={1920} fps={60} durationInFrames={1} defaultProps={{variant: 'A' as 'A' | 'B' | 'C'}} />
  <Composition id="Eiffel" component={Eiffel} width={1080} height={1920} fps={FPS}
    durationInFrames={Math.ceil(DURATION * FPS)} />
  </>
);
