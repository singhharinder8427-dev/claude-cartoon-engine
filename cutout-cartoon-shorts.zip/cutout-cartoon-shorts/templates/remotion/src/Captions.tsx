import React from 'react';
import {chunks, words} from './timing';
import {clamp, eob} from './math';

export const Captions: React.FC<{t: number}> = ({t}) => {
  let idx = -1;
  for (let i = 0; i < chunks.length; i++) {
    const c = chunks[i];
    const end = i < chunks.length - 1 ? chunks[i + 1].t0 - 0.04 : c.t1 + 0.45;
    if (t >= c.t0 - 0.04 && t < end) { idx = i; break; }
  }
  if (idx < 0) return null;
  const c = chunks[idx];
  const age = t - (c.t0 - 0.04);
  const pop = eob(clamp(age / 0.16));
  const sc = 0.86 + 0.14 * pop;
  const ws = words.slice(c.first, c.last + 1);
  return (
    <div style={{position: 'absolute', left: 54, right: 54, top: 1385, height: 230, display: 'flex', alignItems: 'center', justifyContent: 'center'}}>
      <div style={{
        transform: `scale(${sc})`, textAlign: 'center', fontFamily: 'Inter, "DejaVu Sans", sans-serif', fontWeight: 900,
        fontSize: 84, lineHeight: 1.08, letterSpacing: -1, color: '#fff',
        WebkitTextStroke: '15px #111', paintOrder: 'stroke fill', textShadow: '0 6px 0 rgba(0,0,0,0.25)',
      } as React.CSSProperties}>
        {ws.map((w, i) => {
          const active = t >= w.t0 && t < w.t1 + 0.02;
          return (
            <span key={i} style={{color: active ? '#FFE14D' : '#fff', display: 'inline-block', transform: active ? 'scale(1.06)' : 'none', marginRight: 18}}>
              {w.w}
            </span>
          );
        })}
      </div>
    </div>
  );
};
