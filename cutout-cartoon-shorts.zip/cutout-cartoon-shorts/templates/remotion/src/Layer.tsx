import React, {createContext, useContext} from 'react';
import {AbsoluteFill} from 'remotion';

export type Cam = {x: number; y: number; z: number};
const KCtx = createContext(1);
/** layer scale: use px/k so outlines keep the same on-screen weight at every depth */
export const useK = () => useContext(KCtx);
export const proj = (Z: number, X: number, Y: number, cam: Cam): [number, number] => {
  const k = 1000 / (Z - cam.z);
  return [540 + (X - cam.x) * k, 960 + (Y - cam.y) * k];
};
export const Layer: React.FC<{cam: Cam; z: number; minDepth?: number; blur?: number; children: React.ReactNode}> =
  ({cam, z, minDepth = 400, blur = 0, children}) => {
    const d = z - cam.z;
    if (d < minDepth) return null;
    const k = 1000 / d;
    return (
      <AbsoluteFill style={{filter: blur > 0.3 ? `blur(${blur.toFixed(1)}px)` : undefined}}>
        <svg width={1080} height={1920} viewBox="0 0 1080 1920" style={{position: 'absolute', left: 0, top: 0}}>
          <g transform={`translate(540 960) scale(${k}) translate(${-cam.x} ${-cam.y})`}>
            <KCtx.Provider value={k}>{children}</KCtx.Provider>
          </g>
        </svg>
      </AbsoluteFill>
    );
  };
