import React from 'react';
import {INK} from './theme';
import {useK} from './Layer';

export type Pose = {
  lean: number; sx: number; sy: number;
  faceDx: number; faceDy: number; lookX: number; lookY: number; eyeOpen: number;
  browY: number; browTilt: number;
  mouth: 'flat' | 'smile' | 'o' | 'open' | 'smirk';
  armL: [number, number]; armR: [number, number];
  sweat: number; sweatSlide: number; headTilt: number;
};

const OL = 9, ARM = 12, SH = '#DDE2EA';

/** flat white round-head character; origin = feet centre, y up is negative */
export const Character: React.FC<{pose: Pose}> = ({pose: p}) => {
  const k = useK(); const lw = (x: number) => x / k;
  const shoulders: [number, number][] = [[-44, -158], [44, -158]];
  const arm = (i: 0 | 1) => {
    const s = i === 0 ? -1 : 1; const [sx, sy] = shoulders[i]; const [hx, hy] = i === 0 ? p.armL : p.armR;
    return `M ${sx} ${sy} Q ${(sx + hx) / 2 + s * 18} ${(sy + hy) / 2 + 24} ${hx} ${hy}`;
  };
  const ex = 36, ey = -8;
  const eyeRy = Math.max(2.5, 14 * p.eyeOpen);
  const lx = p.faceDx + p.lookX * 7, ly = p.faceDy + p.lookY * 8;
  const brow = (side: -1 | 1) => {
    const cx = p.faceDx + side * ex, cy = p.faceDy - 40 + p.browY;
    const inner = p.browTilt * 0.6, outer = -p.browTilt * 0.25;   // + tilt = inner end down (squint/angry), - = inner end up (worried)
    const x0 = cx - 22, x1 = cx + 22;
    const yL = side < 0 ? cy + outer : cy + inner, yR = side < 0 ? cy + inner : cy + outer;
    return `M ${x0} ${yL} Q ${cx} ${cy - 9} ${x1} ${yR}`;
  };
  const mx = p.faceDx, my = p.faceDy + 52;
  const mouth = () => {
    const st = {fill: 'none', stroke: INK, strokeWidth: lw(8), strokeLinecap: 'round' as const};
    switch (p.mouth) {
      case 'flat': return <path d={`M ${mx - 14} ${my} Q ${mx} ${my + 3} ${mx + 14} ${my}`} {...st} />;
      case 'smile': return <path d={`M ${mx - 26} ${my - 4} Q ${mx} ${my + 26} ${mx + 26} ${my - 4}`} {...st} />;
      case 'smirk': return <path d={`M ${mx - 22} ${my + 4} Q ${mx + 6} ${my + 18} ${mx + 26} ${my - 8}`} {...st} />;
      case 'o': return <ellipse cx={mx} cy={my + 4} rx={12} ry={16} fill={INK} />;
      case 'open': return (
        <g>
          <clipPath id="ch-mouth"><path d={`M ${mx - 30} ${my - 8} Q ${mx} ${my + 52} ${mx + 30} ${my - 8} Z`} /></clipPath>
          <path d={`M ${mx - 30} ${my - 8} Q ${mx} ${my + 52} ${mx + 30} ${my - 8} Z`} fill={INK} />
          <g clipPath="url(#ch-mouth)"><ellipse cx={mx} cy={my + 22} rx={14} ry={9} fill="#F58CA0" /></g>
        </g>
      );
    }
  };
  const sw = p.sweat;
  return (
    <g>
      <ellipse cx={0} cy={5} rx={88} ry={15} fill="rgba(40,70,30,0.28)" />
      <g transform={`rotate(${p.lean}) scale(${p.sx} ${p.sy})`}>
        {/* legs */}
        {[-1, 1].map((s) => (
          <g key={s}>
            <path d={`M ${s * 26} -72 L ${s * 30} -14`} stroke={INK} strokeWidth={lw(14 + 2 * OL)} strokeLinecap="round" />
            <path d={`M ${s * 26} -72 L ${s * 30} -14`} stroke="#fff" strokeWidth={lw(14)} strokeLinecap="round" />
            <ellipse cx={s * 46} cy={-10} rx={34} ry={15} fill="#fff" stroke={INK} strokeWidth={lw(OL)} />
          </g>
        ))}
        {/* body */}
        <clipPath id="ch-body"><ellipse cx={0} cy={-130} rx={54} ry={64} /></clipPath>
        <ellipse cx={0} cy={-130} rx={54} ry={64} fill="#fff" />
        <g clipPath="url(#ch-body)"><ellipse cx={0} cy={-130} rx={54} ry={64} fill={SH} /><ellipse cx={-12} cy={-140} rx={54} ry={64} fill="#fff" /></g>
        <ellipse cx={0} cy={-130} rx={54} ry={64} fill="none" stroke={INK} strokeWidth={lw(OL)} />
        {/* arms */}
        {([0, 1] as const).map((i) => (
          <g key={i}>
            <path d={arm(i)} fill="none" stroke={INK} strokeWidth={lw(ARM + 2 * OL)} strokeLinecap="round" />
            <path d={arm(i)} fill="none" stroke="#fff" strokeWidth={lw(ARM)} strokeLinecap="round" />
          </g>
        ))}
        {/* head */}
        <g transform={`translate(0 -250) rotate(${p.headTilt} 0 100)`}>
          <clipPath id="ch-head"><circle r={100} /></clipPath>
          <circle r={100} fill="#fff" />
          <g clipPath="url(#ch-head)"><circle r={100} fill={SH} /><circle cx={-15} cy={-15} r={100} fill="#fff" /></g>
          <circle r={100} fill="none" stroke={INK} strokeWidth={lw(OL)} />
          <ellipse cx={lx - ex} cy={ly + ey} rx={10} ry={eyeRy} fill={INK} />
          <ellipse cx={lx + ex} cy={ly + ey} rx={10} ry={eyeRy} fill={INK} />
          <path d={brow(-1)} fill="none" stroke={INK} strokeWidth={lw(8)} strokeLinecap="round" />
          <path d={brow(1)} fill="none" stroke={INK} strokeWidth={lw(8)} strokeLinecap="round" />
          {mouth()}
          {sw > 0.02 && (
            <g transform={`translate(${88} ${-44 + p.sweatSlide * 70}) scale(${sw})`}>
              <path d="M 0 -22 C 12 -2 17 6 17 15 A 17 17 0 0 1 -17 15 C -17 6 -12 -2 0 -22 Z" fill="#8FD6FF" stroke={INK} strokeWidth={lw(6) / sw} />
              <ellipse cx={-5} cy={12} rx={3.5} ry={6} fill="#fff" />
            </g>
          )}
        </g>
        {/* hands */}
        {[p.armL, p.armR].map((h, i) => <circle key={i} cx={h[0]} cy={h[1]} r={19} fill="#fff" stroke={INK} strokeWidth={lw(OL)} />)}
      </g>
    </g>
  );
};
