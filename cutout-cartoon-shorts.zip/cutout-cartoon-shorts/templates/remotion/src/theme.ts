export const INK = '#151515';
export const C = {
  skyTop: '#74C6FF', skyMid: '#B5E3FF', skyBot: '#E2F4FF',
  hillFar: '#BDE7A6', hillMid: '#A3DB88', ground: '#8DCE6B', near: '#78C158', tuft: '#5DA645',
  shaft: '#C39B68', bar: '#8B6A46', lattice: '#33261B',
  warm: '#FF6A2B', cool: '#8FD3FF',
};
