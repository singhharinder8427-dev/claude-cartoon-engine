import raw from './timing.json';
export const FPS = 60;
/** voice-over: ElevenLabs take, loudness-normalised, placed so its first word lands at 0.40 s */
export const HAS_VOICE = true;
export const VOICE_OFFSET = (raw.voiceOffset ?? 0) as number;
export const words = raw.words as {w: string; t0: number; t1: number; chunk: number}[];
export const chunks = raw.chunks as {text: string; t0: number; t1: number; first: number; last: number}[];
export const DURATION = raw.duration as number;
export const K = raw.key as Record<string, number>;
export const KE = raw.keyEnd as Record<string, number>;
export const PSI_T0 = raw.psiT0 as number;
export const PSI_T1 = raw.psiT1 as number;
export const SUN_EXIT = raw.sunExit as number;
