import React from 'react';
import {AbsoluteFill, Audio, Sequence, staticFile, useCurrentFrame} from 'remotion';
import {Layer, Cam, proj, useK} from './Layer';
import {Sky, FarHills, MidHills, TowerGround, NearGround, Tuft, Cloud} from './Scenery';
import {Sun} from './Sun';
import {Tower, Face, geom, TX, TY, TH} from './Tower';
import {Character, Pose} from './Character';
import {Captions} from './Captions';
import {DURATION, FPS, HAS_VOICE, K, KE, PSI_T0, PSI_T1, SUN_EXIT, VOICE_OFFSET} from './timing';
import {clamp, eio, eioSine, eo, eob, kfs, lin, pick, ramp, blinkAt, lerp} from './math';
import {INK} from './theme';

const DUR = DURATION;
const WIDE_END = KE.wide;
const R_LEAN = 200;          // exaggerated sideways lean of the tip (world px)
const RING_Y = 0.36;         // ring squash (viewed slightly from above)
const CHAR_X = 190, CHAR_Y = 1330;

// ---------------------------------------------------------------- camera
const A: Cam = {x: 540, y: 960, z: 0};          // wide (frame 0 = last frame)
const A2: Cam = {x: 540, y: 950, z: 70};
const B: Cam = {x: 556, y: 1050, z: 560};       // heat close-up, lower tower
const Cc: Cam = {x: 540, y: 900, z: 140};       // pull-back, tower leaning
const D: Cam = {x: 540, y: -285, z: 960};       // tower top, ring
const camKeys: {t: number; c: Cam}[] = [
  {t: 0, c: A}, {t: K.day, c: A2}, {t: K.facing - 0.3, c: A2}, {t: K.heats + 0.6, c: B},
  {t: K.uneven - 0.15, c: B}, {t: K.bends + 0.9, c: Cc}, {t: K.across - 0.3, c: Cc},
  {t: K.traces + 0.3, c: D}, {t: WIDE_END + 0.05, c: D}, {t: DUR, c: A},
];
const REF = 2000;
const zk = (z: number) => 1000 / (REF - z);
const camAt = (t: number): Cam => {
  for (let i = 0; i < camKeys.length - 1; i++) {
    const a = camKeys[i], b = camKeys[i + 1];
    if (t <= b.t) {
      const u = a.t === b.t ? 1 : eio(clamp((t - a.t) / (b.t - a.t)));
      const lk = lerp(Math.log(zk(a.c.z)), Math.log(zk(b.c.z)), u);
      return {x: lerp(a.c.x, b.c.x, u), y: lerp(a.c.y, b.c.y, u), z: REF - 1000 / Math.exp(lk)};
    }
  }
  return A;
};

// ---------------------------------------------------------------- sun / ring motion
const psiOf = (t: number) => 2 * Math.PI * ramp(t, PSI_T0, PSI_T1, eioSine);
const sunU = (t: number) => clamp(psiOf(t) / Math.PI, 0, 1.02);
const sunPos = (t: number) => {
  const u = sunU(t);
  return {x: 170 + (1260 - 170) * u, y: 360 - 170 * Math.sin(Math.PI * Math.min(u, 1))};
};

// ---------------------------------------------------------------- tower face
const faceAt = (t: number): Face => {
  const sp = sunPos(t);
  const follow = ramp(t, K.as - 0.2, K.as + 0.2) * (1 - ramp(t, SUN_EXIT - 0.2, SUN_EXIT + 0.6));
  const lookX0 = kfs(t, [[0, -0.7], [K.never, -0.7], [K.sunny - 0.1, -0.7], [K.sunny + 0.3, -0.85], [K.cooler - 0.3, -0.85], [K.cooler + 0.2, 0.7], [K.uneven, 0.7],
    [K.leans + 0.9, -0.85], [WIDE_END + 0.3, -0.2], [DUR - 0.5, -0.7], [DUR, -0.7]]);
  const lookY0 = kfs(t, [[0, 0.55], [K.sunny - 0.1, 0.55], [K.sunny + 0.3, -0.9], [K.cooler + 0.2, -0.1], [K.uneven, -0.1], [K.leans + 0.9, -0.7], [WIDE_END + 0.3, 0],
    [DUR - 0.5, 0.55], [DUR, 0.55]]);
  const sx = clamp((sp.x - 540) / 340, -1, 1);
  const lidBoth = kfs(t, [[0, 0], [K.sunny, 0], [K.heats, 0.12], [K.expands, 0.5], [K.shaded, 0.55], [K.cooler, 0.5], [K.uneven, 0.3], [K.bends - 0.05, 0.1],
    [K.leans + 0.9, 0.1], [K.as + 0.5, 0.45], [WIDE_END, 0.45], [WIDE_END + 0.2, 0], [DUR, 0]]);
  const lidRsoft = kfs(t, [[0, 0], [K.cooler - 0.2, 0], [K.cooler + 0.3, 0.3], [K.uneven - 0.2, 0.3], [K.uneven + 0.2, 0.25]]);
  const strain = clamp(ramp(t, K.bends, K.bends + 0.2) - ramp(t, K.leans + 0.9, K.leans + 1.2));
  const happy = clamp(ramp(t, WIDE_END + 0.25, WIDE_END + 0.5) - ramp(t, WIDE_END + 1.0, WIDE_END + 1.25));
  return {
    lookX: lerp(lookX0, sx, follow), lookY: lerp(lookY0, -0.75, follow),
    lidL: lidBoth, lidR: t > K.cooler - 0.2 && t < K.uneven + 0.2 ? lidRsoft : lidBoth,
    lidTilt: kfs(t, [[0, 0], [K.heats, 5], [K.expands, 12], [K.cooler, 3], [K.uneven, 0], [DUR, 0]]),
    strain, happy,
    brow: kfs(t, [[0, 0], [K.sunny, 0], [K.heats, 6], [K.expands, 12], [K.cooler, 2], [K.bends, 22], [K.leans + 0.9, 6], [K.as, -3], [DUR, 0]]),
    browL: 0, browR: 0,
    mouth: pick(t, [[0, 'smile'], [K.never, 'flat'], [K.sunny, 'smile'], [K.heats, 'wobble'], [K.shaded, 'smirk'], [K.cooler + 0.1, 'smile'], [K.uneven + 0.2, 'flat'],
      [K.bends, 'grit'], [K.leans + 0.9, 'flat'], [K.as + 0.2, 'smirk'], [WIDE_END + 0.2, 'happy'], [WIDE_END + 1.0, 'smile']] as [number, Face['mouth']][]),
    sweat: kfs(t, [[0, 0], [K.heats, 0], [K.heats + 0.3, 1], [K.cooler + 0.4, 1], [K.cooler + 0.8, 0]]),
    sweatSlide: clamp((t - K.heats - 0.3) / 3.2),
    blink: blinkAt(t, [1.15, 2.7, 4.05, 9.6, 12.0, 18.2, DUR - 0.7]),
  };
};

// ---------------------------------------------------------------- character
const DOWN_L: [number, number] = [-82, -84];
const charPose = (t: number): Pose => {
  const T = K;
  const open = (1 - blinkAt(t, [0.9, 3.2, 8.5, 12.5, DUR - 1.0]));
  const eo_ = kfs(t, [[0, 1], [T.sunny, 1], [T.sunny + 0.3, 0.55], [T.uneven - 0.2, 0.55], [T.uneven + 0.1, 1.15], [DUR - 1.3, 1.1], [DUR - 0.2, 1], [DUR, 1]]);
  return {
    lean: kfs(t, [[0, 0], [0.5, -0.6], [1.5, 0.8], [2.5, -0.5], [3.2, 0], [T.uneven + 0.6, 0], [T.bends + 0.4, 7], [T.leans + 0.8, 7], [T.as, 5.5], [DUR - 1.5, 5.5], [DUR - 0.2, 0], [DUR, 0]]),
    sx: 1, sy: 1 + 0.008 * Math.sin((2 * Math.PI * 16 * t) / DUR),
    faceDx: kfs(t, [[0, 8], [T.sunny - 0.1, 8], [T.sunny + 0.25, -10], [T.uneven, -10], [T.uneven + 0.4, 12], [DUR - 1.5, 12], [DUR - 0.2, 8], [DUR, 8]]),
    faceDy: kfs(t, [[0, -14], [T.sunny - 0.1, -14], [T.sunny + 0.25, -8], [T.uneven, -8], [T.uneven + 0.4, -16], [DUR - 1.5, -16], [DUR - 0.2, -14], [DUR, -14]]),
    lookX: kfs(t, [[0, 0.35], [T.sunny - 0.1, 0.35], [T.sunny + 0.25, -0.8], [T.uneven, -0.8], [T.uneven + 0.4, 0.8], [DUR - 1.5, 0.8], [DUR, 0.35]]),
    lookY: kfs(t, [[0, -0.9], [T.sunny - 0.1, -0.9], [T.sunny + 0.25, -0.7], [T.uneven, -0.7], [T.uneven + 0.4, -1], [DUR - 1.5, -1], [DUR, -0.9]]),
    eyeOpen: eo_ * open,
    browY: kfs(t, [[0, -4], [T.sunny, -4], [T.sunny + 0.3, 6], [T.uneven - 0.2, 6], [T.uneven + 0.1, -12], [DUR - 1.3, -12], [DUR, -4]]),
    browTilt: kfs(t, [[0, -4], [T.sunny, -4], [T.sunny + 0.3, 10], [T.uneven - 0.2, 10], [T.uneven + 0.1, -12], [DUR - 1.3, -12], [DUR, -4]]),
    mouth: pick(t, [[0, 'flat'], [T.never, 'o'], [T.still + 0.4, 'flat'], [T.sunny + 0.1, 'o'], [T.facing, 'flat'], [T.uneven + 0.05, 'open'], [T.leans + 0.7, 'o'],
      [WIDE_END + 0.4, 'smile'], [DUR - 0.8, 'flat']] as [number, Pose['mouth']][]),
    armL: DOWN_L,
    armR: [
      kfs(t, [[0, 82], [T.sunny + 0.1, 82], [T.sunny + 0.5, 96], [T.uneven - 0.1, 96], [T.uneven + 0.4, 82], [T.bends + 0.3, 82], [T.bends + 0.9, 176], [DUR - 1.3, 176], [DUR - 0.3, 82], [DUR, 82]]),
      kfs(t, [[0, -84], [T.sunny + 0.1, -84], [T.sunny + 0.5, -318], [T.uneven - 0.1, -318], [T.uneven + 0.4, -84], [T.bends + 0.3, -84], [T.bends + 0.9, -372], [DUR - 1.3, -372], [DUR - 0.3, -84], [DUR, -84]]),
    ],
    sweat: kfs(t, [[0, 0], [T.sunny + 0.35, 0], [T.sunny + 0.6, 1], [T.uneven, 1], [T.uneven + 0.3, 0]]),
    sweatSlide: clamp((t - T.sunny - 0.6) / 1.5),
    headTilt: 0,
  };
};

// ---------------------------------------------------------------- ring trail + bracket (inside tower layer)
const Ring: React.FC<{psi: number; vis: number; pop: number}> = ({psi, vis, pop}) => {
  const k = useK();
  if (vis < 0.02 || psi < 0.03) return null;
  const cy = TY - TH;
  let d = '';
  for (let a = 0; a <= psi + 1e-6; a += 0.06) d += `${a === 0 ? 'M' : 'L'} ${(TX + R_LEAN * Math.cos(a)).toFixed(1)} ${(cy - RING_Y * R_LEAN * Math.sin(a)).toFixed(1)} `;
  const tip = {x: TX + R_LEAN * Math.cos(psi), y: cy - RING_Y * R_LEAN * Math.sin(psi)};
  const by = cy + RING_Y * R_LEAN + 78, bx = R_LEAN * pop;
  return (
    <g opacity={vis}>
      <path d={d} fill="none" stroke={INK} strokeWidth={19 / k} strokeLinecap="round" strokeDasharray={`${26 / k} ${22 / k}`} />
      <path d={d} fill="none" stroke="#FF5A3C" strokeWidth={10 / k} strokeLinecap="round" strokeDasharray={`${26 / k} ${22 / k}`} />
      <circle cx={tip.x} cy={tip.y} r={17 / k} fill="#FFE14D" stroke={INK} strokeWidth={7 / k} />
      {pop > 0.02 && (
        <g>
          <path d={`M ${TX - bx} ${by} L ${TX + bx} ${by} M ${TX - bx} ${by - 26} L ${TX - bx} ${by + 26} M ${TX + bx} ${by - 26} L ${TX + bx} ${by + 26}`}
            fill="none" stroke={INK} strokeWidth={20 / k} strokeLinecap="round" />
          <path d={`M ${TX - bx} ${by} L ${TX + bx} ${by} M ${TX - bx} ${by - 26} L ${TX - bx} ${by + 26} M ${TX + bx} ${by - 26} L ${TX + bx} ${by + 26}`}
            fill="none" stroke="#fff" strokeWidth={9 / k} strokeLinecap="round" />
        </g>
      )}
    </g>
  );
};

// cloud drift that returns to 0 at the end so the last frame equals the first
const drift = (t: number, a: number) => 160 * a * (1 - Math.cos((2 * Math.PI * t) / DUR)) / 2;

// ---------------------------------------------------------------- composition
export const Eiffel: React.FC = () => {
  const frame = useCurrentFrame();
  const t = frame / FPS;
  const cam = camAt(t);
  const T = K;

  // sun
  const sp = sunPos(t);
  const sunPop = t < T.sunny - 0.1 ? 0 : eob(clamp((t - (T.sunny - 0.1)) / 0.5));
  const sunGone = t > SUN_EXIT - 0.05 ? 0 : 1;
  const sunVisW = 1 - ramp(t, SUN_EXIT - 0.2, SUN_EXIT + 0.8);

  // heat / cool
  const s = clamp((sp.x - 540) / 400, -1, 1.4);
  const wL = clamp(0.5 - 0.6 * s, 0, 1), wR = clamp(0.5 + 0.6 * s, 0, 1);
  const heat = ramp(t, T.facing - 0.1, T.heats + 0.8, eo) * sunVisW;
  const cool = ramp(t, T.shaded, T.cooler + 0.5, eo) * sunVisW;
  const expand = ramp(t, T.iron, T.expands + 0.5, eo);
  const warmL = heat * wL, warmR = heat * wR;
  const coolL = cool * (1 - wL), coolR = cool * (1 - wR);
  const arrowWin = ramp(t, T.iron - 0.1, T.iron + 0.3) * (1 - ramp(t, T.shaded + 0.1, T.shaded + 0.5));

  // lean / ring
  const bend = ramp(t, T.bends - 0.1, T.leans + 0.5, eo);
  const recoil = ramp(t, WIDE_END + 0.2, DUR - 0.3, eio);
  const Rt = R_LEAN * bend * (1 - recoil);
  const psi = psiOf(t);
  const sway = 3.5 * Math.sin(t * 2.9) * ramp(t, 0.25, 0.9) * (1 - ramp(t, T.facing - 0.4, T.facing));
  const lean = {x: Rt * Math.cos(psi) + sway, y: -RING_Y * Rt * Math.sin(psi)};
  const tremble = 2.2 * ramp(t, T.bends, T.bends + 0.1, lin) * (1 - ramp(t, T.leans + 0.1, T.leans + 1.0));
  const ringVis = ramp(t, T.as + 0.2, T.as + 0.8) * (1 - ramp(t, WIDE_END + 0.25, WIDE_END + 1.0));
  const brPop = t < T.fifteen ? 0 : eob(clamp((t - T.fifteen) / 0.4));

  const bulgeL = expand * warmL * 0.9, bulgeR = expand * warmR * 0.9;
  const face = faceAt(t);

  // beams from the sun to the sun-facing edge
  const g = geom(lean, bulgeL, bulgeR);
  const beamAmt = ramp(t, T.facing - 0.1, T.facing + 0.3) * (1 - ramp(t, T.expands + 0.1, T.expands + 0.5)) * sunGone;
  const sunPx = sp;
  const beams = beamAmt > 0.02 ? [0.24, 0.38, 0.52].map((u, i) => {
    const e = g.edge(u, -1);
    const [ex, ey] = proj(2000, e[0], e[1], cam);
    const dx = ex - sunPx.x, dy = ey - sunPx.y, len = Math.hypot(dx, dy);
    const nx = dx / len, ny = dy / len;
    const x0 = sunPx.x + nx * 150, y0 = sunPx.y + ny * 150, x1 = ex - nx * 40, y1 = ey - ny * 40;
    return (
      <g key={i} opacity={beamAmt}>
        <line x1={x0} y1={y0} x2={x1} y2={y1} stroke={INK} strokeWidth={22} strokeLinecap="round" />
        <line x1={x0} y1={y0} x2={x1} y2={y1} stroke="#FFD21F" strokeWidth={11} strokeLinecap="round" strokeDasharray="30 24" strokeDashoffset={-t * 260} />
      </g>
    );
  }) : null;

  // label for the ring
  const [lbx, lby] = proj(2000, TX, TY - TH + RING_Y * R_LEAN + 78, cam);
  const labelOp = ringVis * clamp(brPop);

  // layers
  const charK = 1000 / (1000 - cam.z);
  const tagOp = ramp(t, T.sunny + 0.2, T.sunny + 0.7) * (1 - ramp(t, DUR - 1.6, DUR - 0.6));
  const poseNow = charPose(t);

  return (
    <AbsoluteFill style={{background: '#74C6FF'}}>
      <Sky />
      <Sun x={sp.x} y={sp.y} s={sunPop * sunGone} t={t} />
      <Layer cam={cam} z={5000}>
        <Cloud x={540 + (700 - 540) / 0.2 + drift(t, 1.0)} y={960 + (250 - 960) / 0.2} s={4.2} />
        <Cloud x={540 + (860 - 540) / 0.2 + drift(t, 0.7)} y={960 + (640 - 960) / 0.2} s={3.4} />
        <Cloud x={540 + (250 - 540) / 0.2 + drift(t, 0.85)} y={960 + (760 - 960) / 0.2} s={2.8} />
      </Layer>
      <Layer cam={cam} z={4000}><FarHills /></Layer>
      <Layer cam={cam} z={3000}><MidHills /></Layer>
      <Layer cam={cam} z={2000}>
        <TowerGround />
        <Tower t={t} lean={lean} tremble={tremble} warmL={warmL} warmR={warmR} coolL={coolL} coolR={coolR} bulgeL={bulgeL} bulgeR={bulgeR}
          wavesL={warmL * 0.9} wavesR={warmR * 0.9} arrowsL={arrowWin * wL} arrowsR={arrowWin * wR} face={face} />
        <Ring psi={psi} vis={ringVis} pop={brPop} />
      </Layer>
      <Layer cam={cam} z={1000} minDepth={400} blur={Math.max(0, (charK - 1.4) * 5)}>
        <NearGround />
        <Tuft x={330} y={1345} s={1.3} /><Tuft x={60} y={1362} s={1.1} /><Tuft x={470} y={1390} s={1.5} />
        <g transform={`translate(${CHAR_X} ${CHAR_Y})`}><Character pose={poseNow} /></g>
      </Layer>

      {/* overlays: sun beams, ring label, scale tag */}
      <svg width={1080} height={1920} viewBox="0 0 1080 1920" style={{position: 'absolute', left: 0, top: 0}}>{beams}</svg>
      {labelOp > 0.02 && (
        <div style={{position: 'absolute', left: lbx, top: lby + 34, transform: `translate(-50%, 0) scale(${0.8 + 0.2 * brPop})`, opacity: labelOp, textAlign: 'center',
          fontFamily: 'Inter, sans-serif', fontWeight: 900, color: '#fff', WebkitTextStroke: '12px #111', paintOrder: 'stroke fill', whiteSpace: 'nowrap'} as React.CSSProperties}>
          <div style={{fontSize: 68}}>≈ 15 cm</div>
          <div style={{fontSize: 34, WebkitTextStroke: '9px #111'} as React.CSSProperties}>(drawn far bigger than real)</div>
        </div>
      )}
      <div style={{position: 'absolute', right: 40, top: 1296, textAlign: 'right', opacity: tagOp * 0.92, fontFamily: 'Inter, sans-serif', fontWeight: 800, fontSize: 30,
        color: '#fff', WebkitTextStroke: '8px #111', paintOrder: 'stroke fill', letterSpacing: 1} as React.CSSProperties}>
        exaggerated · not to scale
      </div>
      <Captions t={t} />
      {HAS_VOICE && (
        <Sequence from={Math.round(VOICE_OFFSET * FPS)} layout="none">
          <Audio src={staticFile('eiffel/vo.wav')} volume={1} />
        </Sequence>
      )}
      <Audio src={staticFile('eiffel/sfx.wav')} volume={HAS_VOICE ? 0.42 : 0.9} />
    </AbsoluteFill>
  );
};
