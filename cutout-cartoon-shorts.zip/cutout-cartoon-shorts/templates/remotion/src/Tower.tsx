import React from 'react';
import {INK, C} from './theme';
import {useK} from './Layer';

export const TH = 1900, TX = 540, TY = 1400;       // tower height, base-centre in world px
const ARCH_A = 215, ARCH_U = 0.14;                  // arch half-width and height (fraction of TH)
const FACE_U = 0.29;                                // where the face sits on the tower

export const hwBase = (u: number) => {
  const b = 24 + 336 * Math.exp(-4.3 * u);
  const sp = u > 0.93 ? Math.max(0.12, 1 - ((u - 0.93) / 0.07) * 0.88) : 1;
  return b * sp * 0.98;
};

export type Face = {
  lookX: number; lookY: number;
  lidL: number; lidR: number; lidTilt: number;      // lid cover 0..1, tilt deg (+ = angry)
  strain: number; happy: number;                    // chevron eyes / closed happy eyes
  brow: number; browL: number; browR: number;       // brow tilt deg (+ angry) and y offsets
  mouth: 'smile' | 'flat' | 'o' | 'grit' | 'smirk' | 'wobble' | 'happy';
  sweat: number; sweatSlide: number; blink: number;
};

export type TowerProps = {
  t: number;
  lean: {x: number; y: number};
  tremble: number;
  warmL: number; warmR: number; coolL: number; coolR: number;
  bulgeL: number; bulgeR: number;
  wavesL: number; wavesR: number; arrowsL: number; arrowsR: number;
  face: Face;
};

const f1 = (n: number) => n.toFixed(1);
const pt = (p: [number, number]) => `${f1(p[0])} ${f1(p[1])}`;

/** geometry shared with the overlay (sun beams) */
export const geom = (lean: {x: number; y: number}, bulgeL: number, bulgeR: number, tremble = 0, t = 0) => {
  const off = (u: number) => ({x: lean.x * u * u + tremble * Math.sin(t * 90 + u * 6) * u, y: lean.y * u * u});
  const edge = (u: number, side: -1 | 1): [number, number] => {
    const o = off(u);
    const b = side < 0 ? bulgeL : bulgeR;
    const w = hwBase(u) + b * 40 * Math.sin(Math.PI * Math.min(u, 0.9) / 0.9);
    return [TX + o.x + side * w, TY - u * TH + o.y];
  };
  const cen = (u: number): [number, number] => { const o = off(u); return [TX + o.x, TY - u * TH + o.y]; };
  const arch = (th: number): [number, number] => {
    const au = ARCH_U * Math.sin(th); const o = off(au);
    return [TX + o.x + ARCH_A * Math.cos(th), TY - au * TH + o.y];
  };
  const archInner = (u: number, side: -1 | 1): [number, number] => {
    const o = off(u); const ax = ARCH_A * Math.sqrt(Math.max(0, 1 - (u / ARCH_U) * (u / ARCH_U)));
    return [TX + o.x + side * ax, TY - u * TH + o.y];
  };
  return {off, edge, cen, arch, archInner};
};

const Eye: React.FC<{id: string; cx: number; side: -1 | 1; f: Face}> = ({id, cx, side, f}) => {
  const k = useK(); const lw = (x: number) => x / k;
  const rx = 34, ry = 46;
  const lid = Math.max(side < 0 ? f.lidL : f.lidR, f.blink);
  const tilt = f.lidTilt * (side < 0 ? 1 : -1);
  const px = f.lookX * 11, py = f.lookY * 13;
  const lidY = -ry + lid * 2 * ry;
  const eyeOp = 1 - Math.max(f.strain, f.happy);
  return (
    <g transform={`translate(${cx} 0)`}>
      <g opacity={eyeOp}>
        <clipPath id={id}><ellipse rx={rx} ry={ry} /></clipPath>
        <ellipse rx={rx} ry={ry} fill="#fff" />
        <g clipPath={`url(#${id})`}>
          <circle cx={px} cy={py} r={17} fill={INK} />
          <circle cx={px - 5} cy={py - 7} r={5.5} fill="#fff" />
          {lid > 0.02 && (
            <g transform={`rotate(${tilt})`}>
              <rect x={-rx - 24} y={-ry - 60} width={2 * rx + 48} height={lidY + ry + 60} fill={C.shaft} />
              <line x1={-rx - 24} x2={rx + 24} y1={lidY} y2={lidY} stroke={INK} strokeWidth={lw(8)} />
            </g>
          )}
        </g>
        <ellipse rx={rx} ry={ry} fill="none" stroke={INK} strokeWidth={lw(8)} />
      </g>
      {f.strain > 0.02 && (
        <path d={side < 0 ? 'M -24 -24 L 14 0 L -24 24' : 'M 24 -24 L -14 0 L 24 24'} fill="none" stroke={INK}
          strokeWidth={lw(11)} strokeLinecap="round" strokeLinejoin="round" opacity={f.strain} />
      )}
      {f.happy > 0.02 && (
        <path d="M -32 10 Q 0 -34 32 10" fill="none" stroke={INK} strokeWidth={lw(11)} strokeLinecap="round" opacity={f.happy} />
      )}
    </g>
  );
};

const Mouth: React.FC<{m: Face['mouth']}> = ({m}) => {
  const k = useK(); const lw = (x: number) => x / k;
  const st = {fill: 'none', stroke: INK, strokeWidth: lw(10), strokeLinecap: 'round' as const, strokeLinejoin: 'round' as const};
  switch (m) {
    case 'flat': return <path d="M -26 6 L 26 6" {...st} />;
    case 'smile': return <path d="M -36 0 Q 0 36 36 0" {...st} />;
    case 'smirk': return <path d="M -30 10 Q 8 24 38 -8" {...st} />;
    case 'wobble': return <path d="M -34 6 Q -17 -10 0 6 T 34 6" {...st} />;
    case 'o': return <ellipse rx={16} ry={21} fill={INK} stroke={INK} strokeWidth={lw(6)} />;
    case 'grit': return (
      <g>
        <rect x={-42} y={-14} width={84} height={38} rx={10} fill="#fff" stroke={INK} strokeWidth={lw(8)} />
        <path d="M -21 -14 L -21 24 M 0 -14 L 0 24 M 21 -14 L 21 24 M -42 5 L 42 5" stroke={INK} strokeWidth={lw(5)} fill="none" />
      </g>
    );
    case 'happy': return (
      <g>
        <clipPath id="tw-mouth"><path d="M -42 -6 Q 0 56 42 -6 Z" /></clipPath>
        <path d="M -42 -6 Q 0 56 42 -6 Z" fill={INK} />
        <g clipPath="url(#tw-mouth)"><ellipse cx={0} cy={26} rx={20} ry={12} fill="#F58CA0" /></g>
      </g>
    );
  }
};

const Star: React.FC<{x: number; y: number; r: number; rot?: number}> = ({x, y, r, rot = 0}) => {
  const k = useK();
  const p = `M 0 ${-r} Q ${r * 0.18} ${-r * 0.18} ${r} 0 Q ${r * 0.18} ${r * 0.18} 0 ${r} Q ${-r * 0.18} ${r * 0.18} ${-r} 0 Q ${-r * 0.18} ${-r * 0.18} 0 ${-r} Z`;
  return <path transform={`translate(${x} ${y}) rotate(${rot})`} d={p} fill="#EAF9FF" stroke={INK} strokeWidth={5 / k} strokeLinejoin="round" />;
};

export const Tower: React.FC<TowerProps> = (p) => {
  const k = useK(); const lw = (x: number) => x / k;
  const {t, lean, tremble} = p;
  const {off, edge, cen, arch, archInner} = geom(lean, p.bulgeL, p.bulgeR, tremble, t);
  const U = Array.from({length: 91}, (_, i) => i / 90);

  // silhouette with the arch cut out of the base
  let d = `M ${pt(edge(0, -1))}`;
  U.slice(1).forEach((u) => (d += ` L ${pt(edge(u, -1))}`));
  U.slice().reverse().forEach((u) => (d += ` L ${pt(edge(u, 1))}`));
  for (let i = 0; i <= 30; i++) d += ` L ${pt(arch((Math.PI * i) / 30))}`;
  d += ' Z';

  let leftHalf = `M ${pt(edge(0, -1))}`;
  U.slice(1).forEach((u) => (leftHalf += ` L ${pt(edge(u, -1))}`));
  U.slice().reverse().forEach((u) => (leftHalf += ` L ${pt(cen(u))}`));
  leftHalf += ' Z';
  let rightHalf = `M ${pt(cen(0))}`;
  U.slice(1).forEach((u) => (rightHalf += ` L ${pt(cen(u))}`));
  U.slice().reverse().forEach((u) => (rightHalf += ` L ${pt(edge(u, 1))}`));
  rightHalf += ' Z';

  // lattice
  const lat: React.ReactNode[] = [];
  const ln = (a: [number, number], b: [number, number], key: string, w = 4.5) => (
    <line key={key} x1={a[0]} y1={a[1]} x2={b[0]} y2={b[1]} stroke={C.lattice} strokeWidth={lw(w)} strokeLinecap="round" opacity={0.9} />
  );
  const levels = [0.14, 0.17, 0.24, 0.31, 0.40, 0.47, 0.55, 0.63, 0.71, 0.80, 0.86, 0.92, 0.97];
  for (let i = 0; i < levels.length - 1; i++) {
    const a = levels[i], b = levels[i + 1];
    lat.push(ln(edge(a, -1), edge(b, 1), `xa${i}`), ln(edge(a, 1), edge(b, -1), `xb${i}`), ln(edge(a, -1), edge(a, 1), `h${i}`, 3.5));
  }
  const legU = [0, 0.035, 0.07, 0.105, 0.14];
  for (let i = 0; i < legU.length; i++) {
    for (const s of [-1, 1] as const) {
      lat.push(ln(edge(legU[i], s), archInner(legU[i], s), `r${i}${s}`, 3.5));
      if (i < legU.length - 1) {
        lat.push(ln(edge(legU[i], s), archInner(legU[i + 1], s), `da${i}${s}`), ln(archInner(legU[i], s), edge(legU[i + 1], s), `db${i}${s}`));
      }
    }
  }

  const bar = (u: number, h: number, ext: number, key: string) => {
    const L = edge(u, -1), R = edge(u, 1);
    return <rect key={key} x={L[0] - ext} y={L[1] - h / 2} width={R[0] - L[0] + 2 * ext} height={h} rx={h * 0.28} fill={C.bar} stroke={INK} strokeWidth={lw(8)} />;
  };

  // face
  const fc = cen(FACE_U);
  const f = p.face;
  const browY = -76;
  const browPath = 'M -34 4 Q 0 -10 34 4';

  // heat waves
  const waves = (side: -1 | 1, amt: number) => {
    if (amt < 0.02) return null;
    return [0, 1, 2].map((i) => {
      const xb = edge(0.3, side)[0] + side * (62 + i * 58);
      let w = '';
      for (let y = 0; y <= 520; y += 14) {
        const yy = TY - 0.1 * TH - y;
        const taper = Math.sin(Math.PI * (y / 520));
        const x = xb + 18 * Math.sin(y * 0.024 + i * 2.1 - t * 6.5) * taper;
        w += `${y === 0 ? 'M' : 'L'} ${f1(x)} ${f1(yy)} `;
      }
      return <path key={i} d={w} fill="none" stroke="#FF7A2E" strokeWidth={lw(8)} strokeLinecap="round" opacity={0.9 * amt} />;
    });
  };
  const arrows = (side: -1 | 1, amt: number) => {
    if (amt < 0.02) return null;
    return [0.2, 0.4, 0.6].map((u, i) => {
      const e = edge(u, side);
      const bob = -16 * Math.abs(Math.sin(t * 4.2 + i * 1.3));
      return (
        <g key={i} transform={`translate(${e[0] + side * 56} ${e[1] + bob}) scale(${1.25 * amt})`} opacity={amt}>
          <path d="M 0 -50 L 30 -8 L 11 -8 L 11 42 L -11 42 L -11 -8 L -30 -8 Z" fill="#FF9440" stroke={INK} strokeWidth={lw(7) / (1.25 * amt)} strokeLinejoin="round" />
        </g>
      );
    });
  };
  const sparks = (side: -1 | 1, amt: number) => {
    if (amt < 0.02) return null;
    return [0.3, 0.5, 0.68].map((u, i) => {
      const e = edge(u, side);
      const s = (0.55 + 0.45 * Math.sin(t * 5 + i * 2)) * amt;
      return <Star key={i} x={e[0] + side * (40 + i * 10)} y={e[1]} r={26 * Math.max(0.1, s)} rot={i * 15} />;
    });
  };

  return (
    <g>
      <clipPath id="twr-shape"><path d={d} /></clipPath>
      <path d={d} fill={C.shaft} />
      <g clipPath="url(#twr-shape)">
        <path d={leftHalf} fill={C.warm} opacity={0.62 * p.warmL} />
        <path d={leftHalf} fill={C.cool} opacity={0.55 * p.coolL} />
        <path d={rightHalf} fill={C.warm} opacity={0.62 * p.warmR} />
        <path d={rightHalf} fill={C.cool} opacity={0.55 * p.coolR} />
        {lat}
      </g>
      <path d={d} fill="none" stroke={INK} strokeWidth={lw(9)} strokeLinejoin="round" />
      {bar(0.17, 46, 36, 'b1')}
      {bar(0.40, 34, 28, 'b2')}
      {bar(0.80, 26, 22, 'b3')}
      {bar(0.955, 18, 14, 'b4')}

      {/* face */}
      <g transform={`translate(${fc[0]} ${fc[1]})`}>
        <Eye id="twr-eyeL" cx={-56} side={-1} f={f} />
        <Eye id="twr-eyeR" cx={56} side={1} f={f} />
        <g transform={`translate(-56 ${browY + f.browL}) rotate(${f.brow})`}><path d={browPath} fill="none" stroke={INK} strokeWidth={lw(12)} strokeLinecap="round" /></g>
        <g transform={`translate(56 ${browY + f.browR}) rotate(${-f.brow})`}><path d={browPath} fill="none" stroke={INK} strokeWidth={lw(12)} strokeLinecap="round" /></g>
        <g transform="translate(0 78)"><Mouth m={f.mouth} /></g>
        {f.sweat > 0.02 && (
          <g transform={`translate(${-112} ${-34 + f.sweatSlide * 110}) scale(${f.sweat * 1.25})`}>
            <path d="M 0 -26 C 14 -2 20 8 20 18 A 20 20 0 0 1 -20 18 C -20 8 -14 -2 0 -26 Z" fill="#8FD6FF" stroke={INK} strokeWidth={lw(6) / (f.sweat * 1.25)} />
            <ellipse cx={-6} cy={14} rx={4} ry={7} fill="#fff" opacity={0.9} />
          </g>
        )}
      </g>

      {waves(-1, p.wavesL)}{waves(1, p.wavesR)}
      {arrows(-1, p.arrowsL)}{arrows(1, p.arrowsR)}
      {sparks(-1, p.coolL * 0.0 + (p.coolL > p.coolR ? p.coolL : 0))}
      {sparks(1, p.coolR > p.coolL ? p.coolR : 0)}
    </g>
  );
};
