import React from 'react';
import {INK} from './theme';

/** screen-space cartoon sun with sunglasses */
export const Sun: React.FC<{x: number; y: number; s: number; t: number}> = ({x, y, s, t}) => {
  if (s <= 0.01) return null;
  const R = 105;
  const rays = Array.from({length: 12}, (_, i) => i * 30 + t * 14);
  return (
    <svg width={1080} height={1920} viewBox="0 0 1080 1920" style={{position: 'absolute', left: 0, top: 0}}>
      <g transform={`translate(${x} ${y}) scale(${s})`}>
        <defs><radialGradient id="sunGlow"><stop offset="0" stopColor="#FFFFFF" stopOpacity="0.65" /><stop offset="0.45" stopColor="#FFF6C8" stopOpacity="0.35" /><stop offset="1" stopColor="#FFF6C8" stopOpacity="0" /></radialGradient></defs>
        <circle r={330} fill="url(#sunGlow)" />
        {rays.map((a, i) => (
          <polygon key={i} transform={`rotate(${a})`} points={`-24,${-R - 6} 24,${-R - 6} 0,${-R - 64}`}
            fill="#FFC21A" stroke={INK} strokeWidth={9} strokeLinejoin="round" />
        ))}
        <circle r={R} fill="#FFD94A" stroke={INK} strokeWidth={9} />
        <path d="M -70 40 A 82 82 0 0 0 70 40" fill="none" stroke="#F5B71C" strokeWidth={0} />
        <g>
          <rect x={-78} y={-34} width={68} height={46} rx={16} fill={INK} />
          <rect x={10} y={-34} width={68} height={46} rx={16} fill={INK} />
          <rect x={-12} y={-24} width={24} height={9} fill={INK} />
          <path d="M -64 -24 L -44 -24" stroke="#fff" strokeWidth={7} strokeLinecap="round" opacity={0.85} />
          <path d="M 24 -24 L 44 -24" stroke="#fff" strokeWidth={7} strokeLinecap="round" opacity={0.85} />
          <path d="M -34 40 Q 8 66 44 28" fill="none" stroke={INK} strokeWidth={9} strokeLinecap="round" />
        </g>
      </g>
    </svg>
  );
};
