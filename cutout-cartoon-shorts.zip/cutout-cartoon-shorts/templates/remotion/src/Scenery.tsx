import React from 'react';
import {AbsoluteFill} from 'remotion';
import {INK, C} from './theme';
import {useK} from './Layer';

export const Sky: React.FC = () => (
  <AbsoluteFill style={{background: `linear-gradient(180deg, ${C.skyTop} 0%, ${C.skyMid} 52%, ${C.skyBot} 78%)`}} />
);

const hill = (y0: number, amp: number, wl: number, ph: number, x0 = -5000, x1 = 7000, step = 150) => {
  let d = `M ${x0} ${y0 + 6000}`;
  for (let x = x0; x <= x1; x += step) d += ` L ${x} ${(y0 - amp * (0.5 + 0.5 * Math.sin(x / wl + ph))).toFixed(1)}`;
  return d + ` L ${x1} ${y0 + 6000} Z`;
};
export const FarHills: React.FC = () => <path d={hill(1480, 170, 1100, 0.6)} fill={C.hillFar} />;
export const MidHills: React.FC = () => <path d={hill(1470, 260, 1700, 2.1)} fill={C.hillMid} />;

/** flat ground bands that sit behind (and under) the tower at its depth */
export const TowerGround: React.FC = () => (
  <g>
    <rect x={-6000} y={1330} width={13000} height={6000} fill={C.ground} />
    <ellipse cx={540} cy={1404} rx={470} ry={34} fill="rgba(40,70,30,0.22)" />
  </g>
);
export const NearGround: React.FC = () => <rect x={-6000} y={1250} width={13000} height={7000} fill={C.near} />;

export const Tuft: React.FC<{x: number; y: number; s?: number}> = ({x, y, s = 1}) => (
  <g transform={`translate(${x} ${y}) scale(${s})`} fill={C.tuft}>
    <path d="M -16 0 L -10 -34 L -3 0 Z" /><path d="M -5 0 L 4 -46 L 13 0 Z" /><path d="M 8 0 L 22 -30 L 24 0 Z" />
  </g>
);

export const Cloud: React.FC<{x: number; y: number; s: number}> = ({x, y, s}) => {
  const k = useK();
  const o = 7 / (k * s);
  const circles: [number, number, number][] = [[0, 0, 60], [70, -28, 76], [150, -6, 62], [212, 14, 48], [-56, 18, 44], [100, 26, 58]];
  return (
    <g transform={`translate(${x} ${y}) scale(${s})`}>
      {circles.map(([cx, cy, r], i) => <circle key={'i' + i} cx={cx} cy={cy} r={r + o} fill={INK} />)}
      {circles.map(([cx, cy, r], i) => <circle key={'f' + i} cx={cx} cy={cy} r={r} fill="#fff" />)}
    </g>
  );
};
